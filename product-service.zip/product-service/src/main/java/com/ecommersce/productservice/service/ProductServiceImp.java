package com.ecommersce.productservice.service;

import com.ecommersce.productservice.dao.ProductRepository;
import com.ecommersce.productservice.entity.Products;
import com.ecommersce.productservice.model.OrderServiceResponse;
import com.ecommersce.productservice.model.ProductData;
import com.ecommersce.productservice.util.GenerateProductsId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImp implements ProductService{

   @Autowired
   private ProductRepository productRepository;

    @Override
    public void createProduct(ProductData data) {
        Products productEntity=new Products();
        productEntity.setProductId(GenerateProductsId.getUniqueProductsId());
        productEntity.setProductName(data.getProductName());
        productEntity.setCategory(data.getCategory());
        productEntity.setDate(data.getDate());
        productEntity.setStock(data.getStock());
        productEntity.setRating(data.getRating());
        productEntity.setPrice(data.getPrice());
        productRepository.save(productEntity);

    }

    @Override
    public void createListOfProduct(List<ProductData> data) {
        List<Products> productEntity=new ArrayList<>();

        for(ProductData s:data){
            Products entity=new Products();
            entity.setPrice(s.getPrice());
            entity.setRating(s.getPrice());
            entity.setCategory(s.getCategory());
            entity.setProductName(s.getProductName());
            entity.setDate(s.getDate());
            entity.setStock(s.getStock());
            productEntity.add(entity);
        }


        productRepository.saveAll(productEntity);

    }

    @Override
    public void updateProduct(String id,ProductData data) {
        Optional<Products> entity= productRepository.findById(id);
    if(entity.isPresent()){
    Products productEntity = entity.get();
    productEntity.setProductName(data.getProductName());
    productEntity.setCategory(data.getCategory());
    productEntity.setDate(data.getDate());
    productEntity.setStock(data.getStock());
    productEntity.setRating(data.getRating());
    productEntity.setPrice(data.getPrice());
    productRepository.save(productEntity);

    }else{

    //throw exception

}

    }

    @Override
    public void DeleteProduct(String id) {

        Optional<Products> entity= productRepository.findById(id);
        entity.ifPresent(products -> productRepository.delete(products));
    }

    @Override
    public ProductData getProductByProductId(String id) {

        Optional<Products> entity=  productRepository.findByProductId(id);
ProductData data=new ProductData();
       if(entity.isPresent()){
           data.setProductName(entity.get().getProductName());
           data.setCategory(entity.get().getCategory());
           data.setDate(entity.get().getDate());
           data.setStock(entity.get().getStock());
           data.setRating(entity.get().getRating());
           data.setPrice(entity.get().getPrice());
       }


        return data;
    }

    @Override
    public List<ProductData> getProductByName(String name) {
        List<Products> entity=  productRepository.findByProductName(name);
        List<ProductData>data=new ArrayList<>();

        for (Products s:entity) {
            ProductData a=new ProductData();
            a.setProductName(s.getProductName());
            a.setCategory(s.getCategory());
            a.setDate(s.getDate());
            a.setStock(s.getStock());
            a.setRating(s.getRating());
            a.setPrice(s.getPrice());
            data.add(a);
        }


        return data;
    }

    @Override
    public List<ProductData> getProductByCategory(String category) {
        List<Products> products=  productRepository.findByProductCategory(category);
        List<ProductData> productDataList=new ArrayList<>();

        for (Products s:products) {
            ProductData productData=new ProductData();
            productData.setProductName(s.getProductName());
            productData.setCategory(s.getCategory());
            productData.setDate(s.getDate());
            productData.setStock(s.getStock());
            productData.setRating(s.getRating());
            productData.setPrice(s.getPrice());
            productDataList.add(productData);
        }


        return productDataList;
    }

    @Override
    public List<ProductData> getProductByPrice(Double minPrice ,Double maxPrice) {
        List<Products> productEntity=  productRepository.findByProductPrice(minPrice,maxPrice);
        List<ProductData>data=new ArrayList<>();
        ProductData a=new ProductData();
        for (Products s:productEntity) {
            a.setProductName(s.getProductName());
            a.setCategory(s.getCategory());
            a.setDate(s.getDate());
            a.setStock(s.getStock());
            a.setRating(s.getRating());
            a.setPrice(s.getPrice());

        }
        data.add(a);

        return data;
    }

    @Override
    public List<ProductData> getProductByRating(Double rating) {
        List<Products> entity=  productRepository.findByRating(rating);
        List<ProductData>data=new ArrayList<>();
        ProductData a=new ProductData();
        for (Products s:entity) {
            a.setProductName(s.getProductName());
            a.setCategory(s.getCategory());
            a.setDate(s.getDate());
            a.setStock(s.getStock());
            a.setRating(s.getRating());
            a.setPrice(s.getPrice());

        }
        data.add(a);

        return data;


    }

    @Override
    public List<OrderServiceResponse> getListOfStock(List<String> productsId) {

        List<Products> stocks= productRepository.getProductsById(productsId);
        List<OrderServiceResponse> stockInformation=new ArrayList<>();
        for(Products stock:stocks){
            OrderServiceResponse productsIdAndStock=new OrderServiceResponse();
            productsIdAndStock.setProductId(stock.getProductId());
            productsIdAndStock.setStock(stock.getStock());
            stockInformation.add(productsIdAndStock);
        }

        return stockInformation;
    }
}
