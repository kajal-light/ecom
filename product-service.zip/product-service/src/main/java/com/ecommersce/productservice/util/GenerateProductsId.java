package com.ecommersce.productservice.util;

import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class GenerateProductsId {


    public static String getUniqueProductsId(){

        UUID uuid=UUID.randomUUID();
        return uuid.toString();

    }

}
